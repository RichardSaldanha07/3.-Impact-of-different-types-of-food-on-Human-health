# -*- coding: utf-8 -*-
"""
Created on Thu Dec 12 16:07:53 2019

@author: shreyas
"""

#!/usr/bin/env python
# coding: utf-8

# In[ ]:

#Rerieving the Data from the API(Part 2)

import requests
import json
import os,re,datetime
import flatten_json as flatten
import pandas as pd




# In[ ]:


headers1={'user-key' : '87dba3c503cb44085c0c4bf4daefdc0f'}
read_rest1=[]
rest_list1=[]
f = [259,66,89,74,70,63,62,64,58,59,51,61,276,260,67,256,170,103,11071,65,382,56,68,278,296,73,294,146,10564,78,394,57,323,
     279,298,81,367,90,172,385,254,320,281]

for i in f:
    read_rest1=[]
    rests_url=('https://developers.zomato.com/api/v2.1/search?entity_id='+str(i)+'&entity_type=city&start=21&count=40')# fetching the data from this url    
    get_request = requests.get(rests_url,headers=headers1)
    read_rest1=json.loads(get_request.text)
    rest_list1.append(read_rest1)
rest_list1




# In[ ]:
#Parsing the data


x = rest_list1



# In[ ]:


x0 = pd.DataFrame(x[0])
x1 = pd.DataFrame(x[1])
x2 = pd.DataFrame(x[2])
x3= pd.DataFrame(x[3])
x4 = pd.DataFrame(x[4])
x5 = pd.DataFrame(x[5])
x6 = pd.DataFrame(x[6])
x7 = pd.DataFrame(x[7])
x8 = pd.DataFrame(x[8])
x9 = pd.DataFrame(x[9])


# In[ ]:


b0={}

for i in x0:
    a = x0.get(i)

for i in range(20):
     b0[i]= a[i]['restaurant']
        


b1={}

for i in x1:
    a = x1.get(i)

for i in range(20):
     b1[i]= a[i]['restaurant']
        
        
b2={}

for i in x2:
    a = x2.get(i)

for i in range(20):
     b2[i]= a[i]['restaurant']

b3={}

for i in x3:
    a = x3.get(i)

for i in range(20):
     b3[i]= a[i]['restaurant']
        
        
b4={}

for i in x4:
    a = x4.get(i)

for i in range(20):
     b4[i]= a[i]['restaurant']

b5={}

for i in x5:
    a = x5.get(i)

for i in range(20):
     b5[i]= a[i]['restaurant']
        
        
b6={}

for i in x6:
    a = x6.get(i)

for i in range(20):
     b6[i]= a[i]['restaurant']
        
        
b7={}

for i in x7:
    a = x7.get(i)

for i in range(20):
     b7[i]= a[i]['restaurant']
        
        
b8={}

for i in x8:
    a = x8.get(i)

for i in range(20):
     b8[i]= a[i]['restaurant']
        
        
b9={}

for i in x9:
    a = x9.get(i)

for i in range(20):
     b9[i]= a[i]['restaurant']
        


# In[ ]:


from flatten_json import flatten
flatten(b0)
flatten(b1)
flatten(b2)
flatten(b3)
flatten(b4)
flatten(b5)
flatten(b6)
flatten(b7)
flatten(b8)
flatten(b9)


# In[ ]:


z0 = pd.DataFrame(b0)
result0 = z0.transpose()

z1 = pd.DataFrame(b1)
result1 = z1.transpose()

z2 = pd.DataFrame(b2)
result2 = z2.transpose()


z3= pd.DataFrame(b3)
result3 = z3.transpose()
 
z4= pd.DataFrame(b4)
result4 = z4.transpose()


z5= pd.DataFrame(b5)
result5 = z5.transpose()


z6 = pd.DataFrame(b6)
result6 = z6.transpose()

z7 = pd.DataFrame(b7)
result7 = z7.transpose()


z8= pd.DataFrame(b8)
result8 = z8.transpose()

z9= pd.DataFrame(b9)
result9 = z9.transpose()


# In[ ]:


frames  = [result0,result1,result2,result3,result4,result5,result6,result7,result8,result9]
merge1 = pd.concat(frames)


# In[ ]:


x0 = pd.DataFrame(x[10])
x1 = pd.DataFrame(x[11])
x2 = pd.DataFrame(x[12])
x3 = pd.DataFrame(x[13])
x4 = pd.DataFrame(x[14])
x5 = pd.DataFrame(x[15])
x6 = pd.DataFrame(x[16])
x7 = pd.DataFrame(x[17])
x8 = pd.DataFrame(x[18])
x9 = pd.DataFrame(x[19])


# In[ ]:


b0={}

for i in x0:
    a = x0.get(i)

for i in range(20):
     b0[i]= a[i]['restaurant']
        


b1={}

for i in x1:
    a = x1.get(i)

for i in range(20):
     b1[i]= a[i]['restaurant']
        
        
b2={}

for i in x2:
    a = x2.get(i)

for i in range(20):
     b2[i]= a[i]['restaurant']

b3={}

for i in x3:
    a = x3.get(i)

for i in range(20):
     b3[i]= a[i]['restaurant']
        
        
b4={}

for i in x4:
    a = x4.get(i)

for i in range(20):
     b4[i]= a[i]['restaurant']

b5={}

for i in x5:
    a = x5.get(i)

for i in range(20):
     b5[i]= a[i]['restaurant']
        
        
b6={}

for i in x6:
    a = x6.get(i)

for i in range(20):
     b6[i]= a[i]['restaurant']
        
        

        
b8={}

for i in x8:
    a = x8.get(i)

for i in range(20):
     b8[i]= a[i]['restaurant']
        
        
b9={}

for i in x9:
    a = x9.get(i)

for i in range(20):
     b9[i]= a[i]['restaurant']
        


        


# In[ ]:


flatten(b0)
flatten(b1)
flatten(b2)
flatten(b3)
flatten(b4)
flatten(b5)
flatten(b6)
flatten(b7)
flatten(b8)
flatten(b9)


# In[ ]:


z0 = pd.DataFrame(b0)
result0 = z0.transpose()

z1 = pd.DataFrame(b1)
result1 = z1.transpose()

z2 = pd.DataFrame(b2)
result2 = z2.transpose()


z3= pd.DataFrame(b3)
result3 = z3.transpose()
 
z4= pd.DataFrame(b4)
result4 = z4.transpose()


z5= pd.DataFrame(b5)
result5 = z5.transpose()


z6 = pd.DataFrame(b6)
result6 = z6.transpose()

z7 = pd.DataFrame(b7)
result7 = z7.transpose()


z8= pd.DataFrame(b8)
result8 = z8.transpose()

z9= pd.DataFrame(b9)
result9 = z9.transpose()


# In[ ]:


frames  = [result0,result1,result2,result3,result4,result5,result6,result7,result8,result9]
merge2 = pd.concat(frames)


# In[ ]:


x0 = pd.DataFrame(x[20])
x1 = pd.DataFrame(x[21])
x2 = pd.DataFrame(x[22])
x3= pd.DataFrame(x[23])
x4= pd.DataFrame(x[24])
x5= pd.DataFrame(x[25])
x6= pd.DataFrame(x[26])
x7= pd.DataFrame(x[27])
x8= pd.DataFrame(x[28])
x9= pd.DataFrame(x[29])


# In[ ]:


b0={}

for i in x0:
    a = x0.get(i)

for i in range(20):
     b0[i]= a[i]['restaurant']
        


b1={}

for i in x1:
    a = x1.get(i)

for i in range(20):
     b1[i]= a[i]['restaurant']
        
        
b2={}

for i in x2:
    a = x2.get(i)

for i in range(20):
     b2[i]= a[i]['restaurant']

b3={}

for i in x3:
    a = x3.get(i)

for i in range(20):
     b3[i]= a[i]['restaurant']
        
        
b4={}

for i in x4:
    a = x4.get(i)

for i in range(20):
     b4[i]= a[i]['restaurant']

b5={}

for i in x5:
    a = x5.get(i)

for i in range(20):
     b5[i]= a[i]['restaurant']
        
        
b6={}

for i in x6:
    a = x6.get(i)

for i in range(20):
     b6[i]= a[i]['restaurant']
        
        
b7={}

for i in x7:
    a = x7.get(i)

for i in range(20):
     b7[i]= a[i]['restaurant']
        
        
b8={}

for i in x8:
    a = x8.get(i)

for i in range(20):
     b8[i]= a[i]['restaurant']
        
        
b9={}

for i in x9:
    a = x9.get(i)

for i in range(20):
     b9[i]= a[i]['restaurant']
        


# In[ ]:


flatten(b0)
flatten(b1)
flatten(b2)
flatten(b3)
flatten(b4)
flatten(b5)
flatten(b6)
flatten(b7)
flatten(b8)
flatten(b9)


# In[ ]:


z0 = pd.DataFrame(b0)
result0 = z0.transpose()

z1 = pd.DataFrame(b1)
result1 = z1.transpose()

z2 = pd.DataFrame(b2)
result2 = z2.transpose()


z3= pd.DataFrame(b3)
result3 = z3.transpose()
 
z4= pd.DataFrame(b4)
result4 = z4.transpose()


z5= pd.DataFrame(b5)
result5 = z5.transpose()


z6 = pd.DataFrame(b6)
result6 = z6.transpose()

z7 = pd.DataFrame(b7)
result7 = z7.transpose()


z8= pd.DataFrame(b8)
result8 = z8.transpose()

z9= pd.DataFrame(b9)
result9 = z9.transpose()


# In[ ]:


frames  = [result0,result1,result2,result3,result4,result5,result6,result7,result8,result9]
merge3 = pd.concat(frames)


# In[ ]:


x0 = pd.DataFrame(x[30])
x1 = pd.DataFrame(x[31])
x2 = pd.DataFrame(x[32])
x3= pd.DataFrame(x[33])
x4= pd.DataFrame(x[34])
x5= pd.DataFrame(x[35])
x6= pd.DataFrame(x[36])
x7= pd.DataFrame(x[37])
x8= pd.DataFrame(x[38])
x9= pd.DataFrame(x[39])


# In[ ]:


b0={}

for i in x0:
    a = x0.get(i)

for i in range(20):
     b0[i]= a[i]['restaurant']
        


b1={}

for i in x1:
    a = x1.get(i)

for i in range(20):
     b1[i]= a[i]['restaurant']
        
        
b2={}

for i in x2:
    a = x2.get(i)

for i in range(20):
     b2[i]= a[i]['restaurant']

b3={}

for i in x3:
    a = x3.get(i)

for i in range(20):
     b3[i]= a[i]['restaurant']
        
        
b4={}

for i in x4:
    a = x4.get(i)

for i in range(20):
     b4[i]= a[i]['restaurant']

b5={}

for i in x5:
    a = x5.get(i)

for i in range(20):
     b5[i]= a[i]['restaurant']
        
        
b6={}

for i in x6:
    a = x6.get(i)

for i in range(20):
     b6[i]= a[i]['restaurant']
        
        
b7={}

for i in x7:
    a = x7.get(i)

for i in range(20):
     b7[i]= a[i]['restaurant']
        
        
b8={}

for i in x8:
    a = x8.get(i)

for i in range(20):
     b8[i]= a[i]['restaurant']
        
        
b9={}

for i in x9:
    a = x9.get(i)

for i in range(20):
     b9[i]= a[i]['restaurant']
        


# In[ ]:


flatten(b0)
flatten(b1)
flatten(b2)
flatten(b3)
flatten(b4)
flatten(b5)
flatten(b6)
flatten(b7)
flatten(b8)
flatten(b9)


# In[ ]:


z0 = pd.DataFrame(b0)
result0 = z0.transpose()

z1 = pd.DataFrame(b1)
result1 = z1.transpose()

z2 = pd.DataFrame(b2)
result2 = z2.transpose()


z3= pd.DataFrame(b3)
result3 = z3.transpose()
 
z4= pd.DataFrame(b4)
result4 = z4.transpose()


z5= pd.DataFrame(b5)
result5 = z5.transpose()


z6 = pd.DataFrame(b6)
result6 = z6.transpose()

z7 = pd.DataFrame(b7)
result7 = z7.transpose()


z8= pd.DataFrame(b8)
result8 = z8.transpose()

z9= pd.DataFrame(b9)
result9 = z9.transpose()


# In[ ]:


frames  = [result0,result1,result2,result3,result4,result5,result6,result7,result8,result9]
merge4 = pd.concat(frames)


# In[ ]:


x0 = pd.DataFrame(x[40])
x1 = pd.DataFrame(x[41])
x2 = pd.DataFrame(x[42])


# In[ ]:


b1={}

for i in x0:
    a = x0.get(i)

for i in range(20):
     b1[i]= a[i]['restaurant']
        
        
b2={}

for i in x1:
    a = x1.get(i)

for i in range(20):
     b2[i]= a[i]['restaurant']
        
b3={}

for i in x2:
    a = x2.get(i)

for i in range(20):
     b3[i]= a[i]['restaurant']


# In[ ]:


flatten(b1)
flatten(b2)
flatten(b3)


# In[ ]:


z1 = pd.DataFrame(b1)
result1 = z1.transpose()

z2 = pd.DataFrame(b2)
result2 = z2.transpose()

z3 = pd.DataFrame(b3)
result3 = z2.transpose()


# In[ ]:



frames  = [result1,result2,result3]
merge5 = pd.concat(frames)


# In[ ]:


merge1


# In[ ]:


merge2


# In[ ]:


merge3


# In[ ]:


merge4


# In[ ]:


merge5


# In[ ]:
#Combining the Parsed data


finframe = [merge1,merge2,merge3,merge4,merge5]
mergefinal = pd.concat(finframe)


# In[ ]:


mergefinal1 = mergefinal.reset_index(drop = True)


# In[ ]:


mergefinal1


# In[ ]:


mergefinal1.to_csv("C:\\Users\\shreyas\\Desktop\\dapzom\\zomatofinal2.csv")


# In[9]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:
# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




